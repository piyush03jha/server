clc;
clear;
close;

// Diffusion depth (in um)
x = linspace(0, 4, 200);

// Different sqrt(Dt) values
Dt = [0.1, 0.5, 1];

// Constant total dopant (Normalized)
Q = 1;

// ------------------ Plot 1 (Normal Plot) -------------------
scf(1);
subplot(1,2,1);

for i = 1:1:3
    y = (Q / (sqrt(%pi) * Dt(i))) * exp(-(x.^2) / (4 * (Dt(i)^2)));
    plot(x, y);
end

title("Normalized Gaussian function V/S distance");
xlabel("Diffusion depth x(\mum)");
ylabel("C/S (cm^-1)");
legend("sqrt(Dt)=0.1", "sqrt(Dt)=0.5", "sqrt(Dt)=1");
xgrid();

// ------------------ Plot 2 (Log Plot) -------------------
subplot(1,2,2);

for i = 1:1:3
    y = (Q / (sqrt(%pi) * Dt(i))) * exp(-(x.^2) / (4 * (Dt(i)^2)));
    plot(x, log10(y));
end

title("Normalized Gaussian function V/S distance");
xlabel("Diffusion depth x(\mum)");
ylabel("log10(C/S) (cm^-1)");
legend("sqrt(Dt)=0.1", "sqrt(Dt)=0.5", "sqrt(Dt)=1");
xgrid();
