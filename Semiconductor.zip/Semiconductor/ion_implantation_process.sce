clc;clear;close;
Q = 1;   // normalized dose
// ---------------- Boron ----------------
x1 = linspace(0.1, 0.9, 200);
Rp1 = 0.25;
dRp1 = 0.12;
C1 = (Q/(sqrt(2*%pi)*dRp1)) * exp(-((x1-Rp1).^2)/(2*dRp1^2));
// ---------------- Phosphorus ----------------
x2 = linspace(0.05, 0.4, 200);
Rp2 = 0.13;
dRp2 = 0.07;
C2 = (Q/(sqrt(2*%pi)*dRp2)) * exp(-((x2-Rp2).^2)/(2*dRp2^2));
// ---------------- Arsenic ----------------
x3 = linspace(0.02, 0.2, 200);
Rp3 = 0.07;
dRp3 = 0.04;
C3 = (Q/(sqrt(2*%pi)*dRp3)) * exp(-((x3-Rp3).^2)/(2*dRp3^2));
// ---------------- Plotting ----------------
scf(1);
// Boron Plot
subplot(2,2,1);
plot(x1, log10(C1));
title("Distribution of Boron Implanted Ion");
xlabel("Depth (um)");
ylabel("Concentration");
xgrid();
// Phosphorus Plot
subplot(2,2,2);
plot(x2, log10(C2));
title("Distribution of Phosphorus Implanted Ion");
xlabel("Depth (um)");
ylabel("Concentration");
xgrid();
// Arsenic Plot
subplot(2,2,3);
plot(x3, log10(C3));
title("Distribution of Arsenic Implanted Ion");
xlabel("Depth (um)");
ylabel("Concentration");
xgrid();
