clc;
a = 0:20:200;
D0 = [1, 0.5, 0.25, 0.1, 0.025];

for i = 1:1:5
    y = log10((exp(-10 * (D0(i) / 100) * (a))) * 100);
    plot2d(a, y, style = i)
end

xlabel("Chip size(mm^2)", "fontsize", 4);
ylabel("Yield (%)", "fontsize", 4);
legend("D0=1", "D0=0.5", "D0=0.25", "D0=0.1", "D0=0.025");
