clf();
x = linspace(0, 0.95, 100);

k0 = [1.25, 0.07, 0.35, 0.002, 0.3, 0.72];
labels = ["k1=1.25 Oxygen", "k2=0.07 Carbon", "k3=0.35 Phosphorus", ...
          "k4=0.002 Aluminium", "k5=0.3 Antimony", "k6=0.72 Boron"];

for i = 1:6
    y = k0(i) * ((1 - x).^(k0(i) - 1));
    plot2d(x, y, style=i);
end

title("Dopant Segregation in CZ Crystal Growth", "fontsize", 4);
xlabel("Fraction Solidified (M/M0)", "fontsize", 3);
ylabel("Relative Concentration (Cs/C0)", "fontsize", 3);
legend(labels, "lower right");
xgrid(5);
