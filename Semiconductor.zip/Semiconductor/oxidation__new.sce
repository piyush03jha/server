clc;
// Temperature and Rate Data
t_c = [1200, 1100, 1000, 920, 800, 700];
t1_c = [1200, 1100, 1000, 920];

// Calculations for Dry Oxidation
tk_inv = 1000 ./ (t_c + 273.15);
rate_dry = log10([1.12, 0.3, 0.071, 0.0208, 0.003, 0.00026]);
plot2d(tk_inv, rate_dry, 3);

// Calculations for Wet Oxidation
t1k_inv = 1000 ./ (t1_c + 273.15);
rate_wet = log10([14.4, 4.64, 1.24, 0.406]);
plot2d(t1k_inv, rate_wet, 12);

// Formatting
xlabel("1000/T"); ylabel("log(B/A)");
legend("dry oxidation", "wet oxidation");

// Physical Constants & Activation Energy
k = 1.38e-21; // Combined k and 1000 factor correction
e = -1.6e-19;
m = [-10.28, -7.59]; // Slopes [Dry, Wet]
Ea = (m * 2.303 * 1.38e-23) / e;

// Output Results
printf("\nDry: Slope = %f, Ea = %f eV", m(1), Ea(1));
printf("\nWet: Slope = %f, Ea = %f eV\n", m(2), Ea(2));
