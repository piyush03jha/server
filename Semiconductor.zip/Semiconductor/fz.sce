clc;
x = linspace(0, 9, 100);
ke = [0.01, 0.1, 0.2, 0.5, 0.9, 1, 2, 5];

for i = 1:1:8
    y = 1 - (1 - ke(i)) * (exp((-ke(i) * x)));
    plot2d(x, y, style = i + 1)
end

title("study of float zone technique", "fontsize", 5);
xlabel('x/L', "fontsize", 4);
ylabel('Cs/C0', "fontsize", 4);
legend("k1=0.01", "k2=0.1", "k3=0.2", "k4=0.5", "k5=0.9", "k6=1", "k7=2", "k8=5");
